<?php

class JeapieException extends CException
{
}