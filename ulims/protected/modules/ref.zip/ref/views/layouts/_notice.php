<?php 
	echo rand();
?>